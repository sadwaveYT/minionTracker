package codes.biscuit.skyblockaddons.features;

/**
 * This class keeps track of the number of times players have died during a dungeon run.
 */
public class DungeonDeathCounter {
}