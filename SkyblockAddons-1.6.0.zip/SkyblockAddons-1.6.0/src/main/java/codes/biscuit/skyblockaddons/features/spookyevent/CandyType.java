package codes.biscuit.skyblockaddons.features.spookyevent;

public enum CandyType {

    GREEN,
    PURPLE
}
