package codes.biscuit.skyblockaddons.newfeatures;

public class FeatureBase {
}
