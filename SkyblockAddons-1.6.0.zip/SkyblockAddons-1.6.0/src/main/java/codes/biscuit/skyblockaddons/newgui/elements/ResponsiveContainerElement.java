package codes.biscuit.skyblockaddons.newgui.elements;

public class ResponsiveContainerElement extends ContainerElement {
}
