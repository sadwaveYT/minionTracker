package codes.biscuit.skyblockaddons.shader;

public class ShaderException extends Exception {


}
