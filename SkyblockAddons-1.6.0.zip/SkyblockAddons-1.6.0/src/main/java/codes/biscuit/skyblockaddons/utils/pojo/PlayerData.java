package codes.biscuit.skyblockaddons.utils.pojo;

import codes.biscuit.hypixellocalizationlib.HypixelLanguage;
import lombok.Getter;

@Getter
public class PlayerData {

    private HypixelLanguage language;
}
