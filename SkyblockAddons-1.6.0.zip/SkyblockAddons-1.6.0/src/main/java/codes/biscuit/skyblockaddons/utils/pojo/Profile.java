package codes.biscuit.skyblockaddons.utils.pojo;

import lombok.Getter;

@Getter
public class Profile {

    private String cute_name;
}
